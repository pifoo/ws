<?php
class TestModel extends MongoModel{
    //put your code here
}

?>
