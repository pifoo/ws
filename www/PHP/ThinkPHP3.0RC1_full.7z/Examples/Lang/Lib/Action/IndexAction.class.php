<?php
class IndexAction extends Action{
    public function Index(){
        $this->display();
    }
}
?>