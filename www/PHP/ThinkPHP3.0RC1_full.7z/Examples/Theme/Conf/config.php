<?php
    return array(
        'TMPL_SWITCH_ON' => true, // 启用多模版支持
        'TMPL_DETECT_THEME' => true, // 自动侦测模板主题
    );
?>