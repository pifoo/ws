<?php
    if (!defined('THINK_PATH')) exit();
    return require '../config.php';
?>